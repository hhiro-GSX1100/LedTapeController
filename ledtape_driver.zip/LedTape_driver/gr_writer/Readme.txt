Kurumi Writer is used to write your sketch to GR-KURUMI or compatible board.

DRIVERS:

 Kurumi Writer needs USB driver released by -
 Future Technology Devices International(FTDI).
 To adapt the driver, please visit FTDI Web site as below.
 Drivers: http://www.ftdichip.com/Drivers/VCP.htm
 Outline: http://www.ftdichip.com/FTDrivers.htm

FILES:
 -KurumiWriter_Win.zip (V2.01)
  This is Kurumi Writer for Windows.
  To use this, download and decompress.

 -KurumiWriter_Mac.zip (V2.01)
  This is Kurumi Writer for Mac.
  To use this, download and decompress.

 -samples(*.bin)
  These are samples generated for confirmation in advance.


//*************************************************************************************************
//* Author: hiro 2014/01/31
//* [memo]
//*  Arduino Pro Mini has 512bytes EEPROM(ATmega328 has 1024 bytes)
//*  initial data = 16 bytes
//*  (1 data = ) 24 bytes * 20 = 480 bytes
//*  total 496 bytes
//*  ATmega328 + 480 bytes = 976 bytes
//*************************************************************************************************
#ifndef _USERDATA_H_
#define _USERDATA_H_

#include <EEPROM.h>
#include <LedTape.h>

class UserData{
	public:
		
		//static const byte MAX_OFFSET_VALUE = 20;			// for 512bytes EEPROM on board
		static const byte MAX_OFFSET_VALUE = 40;			// for ATmega328 (1024bytes EEPROM on board)
		
		UserData();
		~UserData();
		void initialize(bool initMemoryOffset = true);	
		void setup();									
		//******************************************************
		//* Getter
		byte getAutoPlay();								
		byte getAutoPlayFrom();							
		byte getAutoPlayTo();							
		byte getLEDs();									
		byte getMaxBrightness();						
		byte getUseBrightness();						
		byte getLedMode();								
		byte getMoveCount();							
		void getUserColor(TColor *tc);					
		byte getUserLedMode();							
		byte getUserBrightness();						
		byte getExecMode();								
		byte getMemoryOffset();							
		byte getDelayTime();							
		byte getLoops();								
		byte getLoopExecMode();							
		void getEarringColor(TColor *tc);				
		byte getEarringBrightness();					
		byte getEarringSpeed();							
		byte getEarringMode();							
		
		//******************************************************
		//* Getter (use position)
		bool isEnableOffsetRange(byte offset_pos);		
		bool isInitData(byte offset_pos);				
		byte getLEDs(byte offset_pos);					
		byte getUseBrightness(byte offset_pos);			
		byte getLedMode(byte offset_pos);				
		byte getMoveCount(byte offset_pos);				
		void getUserColor(byte offset_pos, TColor *tc);	
		byte getUserLedMode(byte offset_pos);			
		byte getUserBrightness(byte offset_pos);		
		byte getExecMode(byte offset_pos);				
		byte getDelayTime(byte offset_pos);				
		byte getLoops(byte offset_pos);					
		byte getLoopExecMode(byte offset_pos);			
		void getEarringColor(byte offset_pos, TColor *tc);	
		byte getEarringBrightness(byte offset_pos);		
		byte getEarringSpeed(byte offset_pos);			
		byte getEarringMode(byte offset_pos);			
		//******************************************************
		//* Setter	
		void setAutoPlay(byte AutoPlay);				
		void setAutoPlayFrom(byte AutoPlayFrom);		
		void setAutoPlayTo(byte AutoPlayTo);			
		void setLEDs(byte LEDs);						
		void setMaxBrightness(byte MaxBrightness);		
		void setUseBrightness(byte UseBrightness);		
		void setLedMode(byte MoveMode);					
		void setMoveCount(byte MoveCount);				
		void setUserColor(TColor *tc);					
		void setUserLedMode(byte MoveMode);				
		void setUserBrightness(byte UserBrightness);	
		void setExecMode(byte ExecMode);				
		void setDelayTime(byte DelayTime);				
		void setLoops(byte Loops);						
		void setLoopExecMode(byte LoopExecMode);		
		void setEarringColor(TColor *tc);				
		void setEarringBrightness(byte EarringBrightness);		
		void setEarringSpeed(byte EarringSpeed);		
		void setEarringMode(byte EarringMode);			
		
		void setMemoryOffset(byte offset);				
		bool clear(byte memory_point);					
	private:
		//initial data
		static const unsigned long MEMORY_OFFSET_VALUE_ADDRESS = 0;
		static const unsigned long AUTOPLAY_ADDRESS = 1;
		static const unsigned long AUTOPLAY_FROM = 2;
		static const unsigned long AUTOPLAY_TO = 3;
		int chkMemoryInitializeKey[4];
		static const unsigned long MemoryInitializeKeyPoint = 10;
		static const byte INIT_VALUE = 0x80;	//Check Value for Initialize
		static const unsigned long DATA_OFFSET = 16;		
		static const unsigned long DATA_CAPACITY = 24;
		unsigned long m_MemoryPoint;
		
		enum DataPoint {
			eInit,
			eLEDs,
			eMaxBrightness,
			eUseBrightness,
			eLedMode,
			eMoveCount,
			eRedValue,
			eGreenValue,
			eBlueValue,
			eUserLedMode,
			eUserBrightness,
			eExecMode,
			eDelayTime,
			eLoops,
			eLoopExecMode,
			eEarringRed,
			eEarringGreen,
			eEarringBlue,
			eEarringBrightness,
			eEarringSpeed,
			eEarringMode
		};
		
		unsigned long getMemoryPoint(DataPoint dp);
		unsigned long getMemoryPoint(byte memory_point, DataPoint dp);
		bool isManagedOffsetRange(byte memory_point);
};

#endif // _USERDATA_H_
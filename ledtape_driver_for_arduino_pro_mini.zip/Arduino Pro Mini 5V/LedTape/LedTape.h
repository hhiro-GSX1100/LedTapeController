//*************************************************************************
//* Author: hiro 2014/01/31
//* This library is customized by hiro.
//*************************************************************************
/*--------------------------------------------------------------------
  This file is part of the Adafruit NeoPixel library.

  NeoPixel is free software: you can redistribute it and/or modify
  it under the terms of the GNU Lesser General Public License as
  published by the Free Software Foundation, either version 3 of
  the License, or (at your option) any later version.

  NeoPixel is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with NeoPixel.  If not, see
  <http://www.gnu.org/licenses/>.
  --------------------------------------------------------------------*/

#ifndef LedTape_H
#define LedTape_H

#if (ARDUINO >= 100)
 #include <Arduino.h>
#else
 #include <WProgram.h>
 #include <pins_arduino.h>
#endif

// 'type' flags for LED pixels (third parameter to constructor):
#define NEO_GRB     0x01 // Wired for GRB data order
#define NEO_COLMASK 0x01
#define NEO_KHZ800  0x02 // 800 KHz datastream
#define NEO_SPDMASK 0x02
// Trinket flash space is tight, v1 NeoPixels aren't handled by default.
// Remove the ifndef/endif to add support -- but code will be bigger.
// Conversely, can comment out the #defines to save space on other MCUs.
#ifndef __AVR_ATtiny85__
#define NEO_RGB     0x00 // Wired for RGB data order
#define NEO_KHZ400  0x00 // 400 KHz datastream
#endif

//custom
#define MAX_OF_LED_NUMBERS 150	//Arduino pro mini can use about 70 LESs.
#define COLOR_RGB       (3)     
struct TColor{
    byte red;
    byte green;
    byte blue;
};        
//memo: uint8_8 = byte, uint16_t = unsigned short, uint32_t = unsigned int, uint64_t = unsigned long long

class LedTape {

 public:
	byte m_brightness;
	enum ExecMode{ AutoSend, ClearAll, ClearAllAndAutoSend, NoClearAndNoSend };    //enums of exec
	// Constructor: pin number, LED type
	LedTape(byte p=6, byte t=NEO_GRB + NEO_KHZ800);
	~LedTape();

	void
		// setup: number of LEDs, brightness  **you must call after instance**
		setup(byte LEDs = 10, byte brightness = 120),
		setPin(byte p),
		setPixelColor(byte n, byte r, byte g, byte b),
		setPixelColor(byte n, uint32_t c),
		setBrightness(byte);
	byte
		*getPixels();
	byte
		numPixels(void);
	static uint32_t
		Color(byte r, byte g, byte b);
	uint32_t
		getPixelColor(byte n);
		
	//add function
	void setLEDs(byte LEDs);
    byte getLEDs();
    void send(void);
	void setAllColors(byte r, byte g, byte b, ExecMode m = AutoSend);
    void setAllColors(TColor c, ExecMode m = AutoSend);
    void setColor(int pos, byte r, byte g, byte b, ExecMode m);
    void setColor(int pos, TColor c, ExecMode m);
	void getColor(int pos, TColor *c);
    void push(TColor c, ExecMode m = AutoSend);
    void pull(TColor c, ExecMode m = AutoSend);
    void reverse(byte led_pos = 0, ExecMode m = AutoSend);
	void copy(byte led_pos, bool common = false); 
    void reverseCopy(byte led_pos, bool common = false);
    void segment(byte led_counts, ExecMode m = AutoSend);
    void segmentReverse(byte led_counts, bool common = true, ExecMode m = AutoSend);
    void mirror(ExecMode m = AutoSend);
	void brightnessReverse(byte led_pos = 0);    //�P�x���]
    void brightnessCopy(byte led_pos, bool common = false);    
    void brightnessReverseCopy(byte led_pos = 0, bool common = false);    //�P�x���]
    void brightnessMirror();
    void clearAllColors();	
	void setAllBrightness(byte br);
    void clearAllBrightness();
    void setBrightness(int pos, byte br);
	byte getBrightness(int pos);

 private:
	
	TColor m_tcolor;
	byte numLEDs;       // Number of RGB LEDs in strip
	uint16_t numBytes;      // Size of 'pixels' buffer below
	
#if defined(NEO_RGB) || defined(NEO_KHZ400)
	const byte
		type;          // Pixel flags (400 vs 800 KHz, RGB vs GRB color)
#endif
	byte
		pin,           // Output pin number
		brightness,
		*pixels,        // Holds LED color values (3 bytes each)
        *p_pixels,
        *p_brightness;
	uint32_t
		endTime;       // Latch timing reference
#ifdef __AVR__
	const volatile byte
		*port;         // Output PORT register
	byte
		pinMask;       // Output PORT bitmask
#endif

	void show(void);
	//add function
    void AllocMemories();
    void FreeMemories();
    void ClearAllPixels();
    void setColor(int pos, byte r, byte g, byte b);
    void setColor(int pos, TColor c);
    void getColor(int pos, byte *r, byte *g, byte *b);
};

#endif // LedTape_H

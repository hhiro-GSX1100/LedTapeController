#ifndef MYTYPE_H_
#define MYTYPE_H_

typedef enum Movement{ eNormal, eReverse, eDouble, eDoubleReverse, eMirror };
typedef enum ExecMode{ eExecLED, eUser };
#endif /* MYTYPE_H_ */

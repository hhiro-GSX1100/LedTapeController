//*************************************************************************************************
//* Author: hiro 2014/01/31
//*************************************************************************************************
#ifndef _COLORLED_H_
#define _COLORLED_H_

#include <Arduino.h>

class ColorLED{
	public:
		ColorLED(int On_Value = LOW);
		~ColorLED();
		//setup method call in setup()
		void setup(int RedPin = 9, int GreenPin = 10, int BluePin = 11, int On_Value = LOW, unsigned long delay_ms = 0);
		void setOnValue(int On_Value = LOW);
		void setDelay(unsigned long ms);
		void setBrightness(byte brightness);
		//*******************************************************************************
		//* Liting method is follow
		//*******************************************************************************
		void Red();
		void Lime();
		void Blue();
		void Yellow();
		void Aqua();
		void Fechsia();
		void White();
		void Black();
		//*******************************************************************************
		//* Caution! if can't use analogWrite, use digitalWrite
		//*******************************************************************************
		void Silver();
		void Gray();
		void Maroon();
		void Purple();
		void Green();
		void Olive();
		void Navy();
		void Teal();
		void LightingLED(byte red_value, byte green_value, byte blue_value);
		void LightingLED(byte red_value, byte green_value, byte blue_value, byte brightness);
	private:
		//*********************************************************************
		int LED_RED_PIN;
		int LED_GREEN_PIN;
		int LED_BLUE_PIN;
		int LED_ON;
		int LED_OFF;
		bool m_RED_enableAnalog;
		bool m_GREEN_enableAnalog;
		bool m_BLUE_enableAnalog;		
		unsigned long m_delay;
		byte m_brightness;
		static const int MIN_PIN_NO = 0;
		static const int MAX_PIN_NO = 17;
		static const int enableAnalogWritePinCount = 6;
		//enable analogWrite Pins
		int enableAnalogWritePinNo[enableAnalogWritePinCount];
		bool chkEnablePin(int ChkPin);
		bool enableAnalogWrite(int ChkPin);
		void MyDelay();
		int byte2int(byte b);
};

#endif // _COLORLED_H_